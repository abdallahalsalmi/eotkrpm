# Architectures

## hardmap 1

![hardmap 1](hardmap-1.png)

## hardmap 2

![hardmap 2](hardmap-2.png)

## softmap 1

![softmap 1](softmap-1.png)

## softmap 2

![softmap 2](softmap-2.png)

## softmap 3

![softmap 3](softmap-3.png)

## softmap 4

![softmap 4](softmap-4.png)

----
*eotk (c) 2017 Alec Muffett*
